document.querySelector(".btn").addEventListener("click", () => {
  //Your Code
});
